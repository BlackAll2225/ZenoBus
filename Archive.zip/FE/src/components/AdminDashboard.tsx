
import { useState } from 'react';
import { 
  DollarSign, 
  Users, 
  Ticket, 
  TrendingUp, 
  TrendingDown,
  Bus,
  Calendar,
  Settings,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  UserCheck,
  UserX
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface DashboardStats {
  dailyRevenue: number;
  totalTickets: number;
  activeUsers: number;
  busOperators: number;
  revenueChange: number;
  ticketChange: number;
}

interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'operator' | 'admin';
  status: 'active' | 'suspended';
  joinDate: string;
  lastLogin: string;
}

interface TicketStat {
  id: string;
  route: string;
  operator: string;
  date: string;
  soldTickets: number;
  totalSeats: number;
  revenue: number;
  status: 'completed' | 'ongoing' | 'cancelled';
}

const AdminDashboard = () => {
  const navigate = useNavigate(); // Hook điều hướng
  const [stats] = useState<DashboardStats>({
    dailyRevenue: 45800000,
    totalTickets: 1247,
    activeUsers: 8456,
    busOperators: 23,
    revenueChange: 12.5,
    ticketChange: -3.2
  });

  const [users] = useState<User[]>([
    {
      id: '1',
      name: 'Nguyen Van A',
      email: 'nguyenvana@email.com',
      role: 'customer',
      status: 'active',
      joinDate: '2024-01-15',
      lastLogin: '2024-12-04'
    },
    {
      id: '2',
      name: 'Phuong Trang Admin',
      email: 'admin@phuongtrang.vn',
      role: 'operator',
      status: 'active',
      joinDate: '2023-11-20',
      lastLogin: '2024-12-04'
    },
    {
      id: '3',
      name: 'Tran Thi B',
      email: 'tranthib@email.com',
      role: 'customer',
      status: 'suspended',
      joinDate: '2024-02-10',
      lastLogin: '2024-11-28'
    }
  ]);

  const [ticketStats] = useState<TicketStat[]>([
    {
      id: '1',
      route: 'Ho Chi Minh City → Da Lat',
      operator: 'Phương Trang',
      date: '2024-12-04',
      soldTickets: 42,
      totalSeats: 48,
      revenue: 5040000,
      status: 'ongoing'
    },
    {
      id: '2',
      route: 'Ha Noi → Da Nang',
      operator: 'Sinh Tourist',
      date: '2024-12-04',
      soldTickets: 36,
      totalSeats: 36,
      revenue: 9000000,
      status: 'completed'
    },
    {
      id: '3',
      route: 'Ho Chi Minh City → Can Tho',
      operator: 'Phương Trang',
      date: '2024-12-04',
      soldTickets: 28,
      totalSeats: 40,
      revenue: 2240000,
      status: 'ongoing'
    }
  ]);

  const getRoleBadge = (role: User['role']) => {
    switch (role) {
      case 'admin':
        return <Badge className="bg-purple-100 text-purple-800">Admin</Badge>;
      case 'operator':
        return <Badge className="bg-blue-100 text-blue-800">Operator</Badge>;
      case 'customer':
        return <Badge variant="secondary">Customer</Badge>;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: User['status']) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'suspended':
        return <Badge className="bg-red-100 text-red-800">Suspended</Badge>;
      default:
        return null;
    }
  };

  const getTripStatusBadge = (status: TicketStat['status']) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case 'ongoing':
        return <Badge className="bg-blue-100 text-blue-800">Ongoing</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-100 text-red-800">Cancelled</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm p-6 mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-gray-600">System overview and management</p>
          </div>
          <div className="flex space-x-4">
            <Button variant="outline">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
            <Button>
              <Calendar className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-7xl">
         {/* Nút quay lại */}
  {/* <Button
    variant="outline"
    size="sm"
    className="mb-6 border-gray-300 text-green-700 hover:bg-green-100"
    onClick={() => navigate(-1)}
  >
    <ArrowLeft className="h-4 w-4 mr-2" />
    Quay lại
  </Button> */}
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Daily Revenue</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.dailyRevenue.toLocaleString()}₫</p>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <DollarSign className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="flex items-center mt-4">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-500 font-medium">+{stats.revenueChange}%</span>
                <span className="text-sm text-gray-500 ml-2">vs yesterday</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Tickets Sold</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalTickets.toLocaleString()}</p>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <Ticket className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="flex items-center mt-4">
                <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                <span className="text-sm text-red-500 font-medium">{stats.ticketChange}%</span>
                <span className="text-sm text-gray-500 ml-2">vs yesterday</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Users</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.activeUsers.toLocaleString()}</p>
                </div>
                <div className="p-3 bg-purple-100 rounded-full">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <div className="flex items-center mt-4">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-500 font-medium">+5.2%</span>
                <span className="text-sm text-gray-500 ml-2">this month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Bus Operators</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.busOperators}</p>
                </div>
                <div className="p-3 bg-orange-100 rounded-full">
                  <Bus className="h-6 w-6 text-orange-600" />
                </div>
              </div>
              <div className="flex items-center mt-4">
                <span className="text-sm text-gray-500">Active partnerships</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="tickets" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tickets">Ticket Statistics</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="operators">Operators</TabsTrigger>
          </TabsList>

          <TabsContent value="tickets">
            <Card>
              <CardHeader>
                <CardTitle>Today's Ticket Sales</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Route</TableHead>
                      <TableHead>Operator</TableHead>
                      <TableHead>Sold/Total</TableHead>
                      <TableHead>Revenue</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ticketStats.map((stat) => (
                      <TableRow key={stat.id}>
                        <TableCell className="font-medium">{stat.route}</TableCell>
                        <TableCell>{stat.operator}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <span>{stat.soldTickets}/{stat.totalSeats}</span>
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${(stat.soldTickets / stat.totalSeats) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="font-semibold">{stat.revenue.toLocaleString()}₫</TableCell>
                        <TableCell>{getTripStatusBadge(stat.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>User Management</CardTitle>
                  <div className="flex space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input className="pl-10" placeholder="Search users..." />
                    </div>
                    <Button>Add User</Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{getRoleBadge(user.role)}</TableCell>
                        <TableCell>{getStatusBadge(user.status)}</TableCell>
                        <TableCell>{user.lastLogin}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Edit className="h-3 w-3" />
                            </Button>
                            {user.status === 'active' ? (
                              <Button variant="outline" size="sm">
                                <UserX className="h-3 w-3" />
                              </Button>
                            ) : (
                              <Button variant="outline" size="sm">
                                <UserCheck className="h-3 w-3" />
                              </Button>
                            )}
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="operators">
            <Card>
              <CardHeader>
                <CardTitle>Bus Operators</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold">Phương Trang</h3>
                        <Badge className="bg-green-100 text-green-800">Active</Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-gray-500">Routes:</span> 45</p>
                        <p><span className="text-gray-500">Daily Revenue:</span> 28,500,000₫</p>
                        <p><span className="text-gray-500">Fleet Size:</span> 120 buses</p>
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-4">
                        View Details
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold">Sinh Tourist</h3>
                        <Badge className="bg-green-100 text-green-800">Active</Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-gray-500">Routes:</span> 28</p>
                        <p><span className="text-gray-500">Daily Revenue:</span> 12,200,000₫</p>
                        <p><span className="text-gray-500">Fleet Size:</span> 85 buses</p>
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-4">
                        View Details
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold">Mai Linh Express</h3>
                        <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-gray-500">Routes:</span> 15</p>
                        <p><span className="text-gray-500">Daily Revenue:</span> 5,100,000₫</p>
                        <p><span className="text-gray-500">Fleet Size:</span> 42 buses</p>
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-4">
                        Review Application
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
