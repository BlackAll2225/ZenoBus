import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Header from './Header';
import Footer from './Footer';
import { useNavigate } from 'react-router-dom';
import { bookingService } from '@/services/bookingService';
import { BookingEntity } from '@/services/types';
import BookingDetailModal from './BookingDetailModal';

const sidebarMenu = [
  { label: 'Thông tin tài khoản', active: false },
  { label: 'Lịch sử mua vé', active: true },
  { label: 'Địa chỉ của bạn', active: false },
  { label: 'Đặt lại mật khẩu', active: false },
  { label: 'Đăng xuất', active: false },
];

export default function UserDashboard() {
  // State filter
  const [filters, setFilters] = useState({ code: '', date: '', route: '', status: 'all' });
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));
  const [username, setUsername] = useState('');
  const navigate = useNavigate();

  // State cho booking data
  const [bookings, setBookings] = useState<BookingEntity[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0
  });
  const [selectedBookingId, setSelectedBookingId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    if (isLoggedIn) {
      const name = localStorage.getItem('username');
      if (name) setUsername(name);
      fetchUserBookings();
    } else {
      // Redirect to login if not logged in
      navigate('/login');
    }
  }, [isLoggedIn, navigate]);

  // Fetch lại data khi pagination thay đổi
  useEffect(() => {
    if (isLoggedIn) {
      fetchUserBookings();
    }
  }, [pagination.page, pagination.limit]);

  const fetchUserBookings = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const result = await bookingService.getUserBookings({
        page: pagination.page,
        limit: pagination.limit
      });
      
      setBookings(result.bookings);
      setPagination({
        page: result.page,
        limit: result.limit,
        total: result.total,
        totalPages: result.totalPages
      });
    } catch (err: unknown) {
      console.error('Error fetching user bookings:', err);
      let errorMessage = 'Có lỗi xảy ra khi tải dữ liệu';
      
      if (err instanceof Error) {
        errorMessage = err.message;
      } else if (typeof err === 'object' && err !== null && 'response' in err) {
        const axiosError = err as { response?: { status?: number; data?: { message?: string } } };
        if (axiosError.response?.status === 401) {
          // Token expired or invalid
          localStorage.removeItem('token');
          localStorage.removeItem('username');
          localStorage.removeItem('userId');
          setIsLoggedIn(false);
          navigate('/login');
          return;
        }
        errorMessage = axiosError.response?.data?.message || errorMessage;
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    setIsLoggedIn(false);
    setUsername('');
    navigate('/');
  };

  // Lọc vé theo filter
  const filteredBookings = bookings.filter(booking => {
    const bookingCode = booking.id?.toString() || '';
    const bookingDate = new Date(booking.schedule?.departureTime || '').toISOString().split('T')[0];
    const bookingRoute = `${booking.route?.departureProvince?.name || ''} - ${booking.route?.arrivalProvince?.name || ''}`;
    const bookingStatus = booking.status || '';

    return (
      (!filters.code || bookingCode.includes(filters.code)) &&
      (!filters.date || bookingDate === filters.date) &&
      (!filters.route || bookingRoute.toLowerCase().includes(filters.route.toLowerCase())) &&
      (filters.status === 'all' || !filters.status || bookingStatus === filters.status)
    );
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('vi-VN');
  };

  const formatPrice = (price: number) => {
    return price?.toLocaleString('vi-VN') + '₫';
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Đang đặt';
      case 'paid': return 'Đã thanh toán';
      case 'cancelled': return 'Đã hủy';
      case 'completed': return 'Hoàn thành';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'paid': return 'text-green-600 bg-green-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      case 'completed': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const handleViewDetail = (bookingId: number) => {
    setSelectedBookingId(bookingId);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedBookingId(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header isLoggedIn={isLoggedIn} username={username} handleLogout={handleLogout} navigate={navigate} />
      <div className="flex-1 flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r flex flex-col py-8 px-4">
          <nav className="space-y-2">
            {sidebarMenu.map((item, idx) => (
              <div
                key={item.label}
                className={`flex items-center px-3 py-2 rounded-lg cursor-pointer text-base font-medium transition-colors ${item.active ? 'bg-orange-100 text-orange-600' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                {item.label}
              </div>
            ))}
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold mb-1">Lịch sử mua vé</h2>
              <p className="text-gray-500 text-sm">Theo dõi và quản lý quá trình lịch sử mua vé của bạn</p>
            </div>
            <Button className="bg-orange-500 hover:bg-orange-600" onClick={() => navigate('/')}>
              Đặt vé
            </Button>
          </div>

          {/* Filter */}
          <div className="flex gap-3 mb-4">
            <Input
              placeholder="Mã vé"
              value={filters.code}
              onChange={e => setFilters(f => ({ ...f, code: e.target.value }))}
              className="w-32"
            />
            <Input
              type="date"
              placeholder="Chọn ngày"
              value={filters.date}
              onChange={e => setFilters(f => ({ ...f, date: e.target.value }))}
              className="w-40"
            />
            <Input
              placeholder="Tuyến đường"
              value={filters.route}
              onChange={e => setFilters(f => ({ ...f, route: e.target.value }))}
              className="w-40"
            />
            <Select
              value={filters.status}
              onValueChange={val => setFilters(f => ({ ...f, status: val }))}
            >
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Trạng thái" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả</SelectItem>
                <SelectItem value="paid">Đã thanh toán</SelectItem>
                <SelectItem value="pending">Đang đặt</SelectItem>
                <SelectItem value="cancelled">Đã hủy</SelectItem>
                <SelectItem value="completed">Hoàn thành</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-green-600 hover:bg-green-700" onClick={() => {
              setPagination(prev => ({ ...prev, page: 1 })); // Reset về trang 1 khi filter
              fetchUserBookings();
            }}>
              Tìm
            </Button>
          </div>

          {/* Error message */}
          {error && (
            <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
              {error}
            </div>
          )}

          {/* Table */}
          <div className="bg-white rounded-lg shadow border">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-2 font-semibold text-left">Mã vé</th>
                  <th className="px-4 py-2 font-semibold text-left">Tuyến đường</th>
                  <th className="px-4 py-2 font-semibold text-left">Ngày đi</th>
                  <th className="px-4 py-2 font-semibold text-left">Số tiền</th>
                  <th className="px-4 py-2 font-semibold text-left">Trạng thái</th>
                  <th className="px-4 py-2 font-semibold text-left">Ngày đặt</th>
                  <th className="px-4 py-2 font-semibold text-left">Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-gray-400">
                      <div className="flex flex-col items-center gap-2">
                        <span className="text-2xl">⏳</span>
                        <span>Đang tải...</span>
                      </div>
                    </td>
                  </tr>
                ) : filteredBookings.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-gray-400">
                      <div className="flex flex-col items-center gap-2">
                        <span className="text-2xl">📄</span>
                        <span>Chưa có lịch sử mua vé</span>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredBookings.map((booking) => (
                    <tr key={booking.id} className="border-t">
                      <td className="px-4 py-2">{booking.id}</td>
                                                                   <td className="px-4 py-2">
                        <div>
                          <div className="font-medium">
                            {booking.route?.departureProvince?.name || ''} - {booking.route?.arrivalProvince?.name || ''}
                          </div>
                          {booking.route?.pickupStop && (
                            <div className="text-xs text-gray-500">
                              Điểm đón: {booking.route.pickupStop}
                            </div>
                          )}
                          {booking.route?.dropoffStop && (
                            <div className="text-xs text-gray-500">
                              Điểm trả: {booking.route.dropoffStop}
                            </div>
                          )}
                        </div>
                      </td>
                                                                   <td className="px-4 py-2">
                        <div>
                          <div className="font-medium">
                            {booking.schedule?.departureTime ? formatDate(booking.schedule.departureTime) : '-'}
                          </div>
                          {booking.bus?.licensePlate && (
                            <div className="text-xs text-gray-500">
                              Xe: {booking.bus.licensePlate} ({booking.bus.busType || ''})
                            </div>
                          )}
                        </div>
                      </td>
                                             <td className="px-4 py-2">
                         <div>
                           <div className="font-medium">
                             {booking.totalPrice ? formatPrice(booking.totalPrice) : '-'}
                           </div>
                           {booking.seats && booking.seats.length > 0 && (
                             <div className="text-xs text-gray-500">
                               {booking.seats.length} ghế: {booking.seats.map(seat => seat.seatNumber || '').join(', ')}
                             </div>
                           )}
                         </div>
                       </td>
                      <td className="px-4 py-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status || '')}`}>
                          {getStatusText(booking.status || '')}
                        </span>
                      </td>
                      <td className="px-4 py-2">
                        {booking.bookedAt ? formatDate(booking.bookedAt) : '-'}
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleViewDetail(booking.id)}
                          >
                            Xem chi tiết
                          </Button>
                          {booking.status === 'pending' && (
                            <Button size="sm" variant="destructive">
                              Hủy vé
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="flex justify-center mt-6 gap-2">
              <Button
                variant="outline"
                disabled={pagination.page <= 1}
                onClick={() => {
                  setPagination(prev => ({ ...prev, page: prev.page - 1 }));
                }}
              >
                Trước
              </Button>
              <span className="px-4 py-2 text-sm">
                Trang {pagination.page} / {pagination.totalPages}
              </span>
              <Button
                variant="outline"
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => {
                  setPagination(prev => ({ ...prev, page: prev.page + 1 }));
                }}
              >
                Sau
              </Button>
            </div>
          )}
        </main>
      </div>
      
      {/* Booking Detail Modal */}
      <BookingDetailModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        bookingId={selectedBookingId}
      />
      
      <Footer />
    </div>
  );
}
